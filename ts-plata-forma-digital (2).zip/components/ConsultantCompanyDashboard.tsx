import React from 'react';

const ConsultantCompanyDashboard: React.FC = () => {
  // This component is no longer used and has been eliminated as per the refactoring.
  // The CompanyView component is now used directly for a unified experience.
  return null; 
};

export default ConsultantCompanyDashboard;
