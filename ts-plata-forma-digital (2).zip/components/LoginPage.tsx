import React, { useState } from 'react';
import { signInWithPopup, signInWithEmailAndPassword } from 'firebase/auth';
import { auth, googleProvider, db } from '../services/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import Logo from './icons/Logo';
import Spinner from './common/Spinner';

const GoogleSignInButton = () => {
    const [isLoading, setIsLoading] = useState(false);

    const handleGoogleSignIn = async () => {
        setIsLoading(true);
        try {
            const result = await signInWithPopup(auth, googleProvider);
            const user = result.user;
            
            const userDocRef = doc(db, "users", user.uid);
            const userDoc = await getDoc(userDocRef);

            if (!userDoc.exists()) {
                // If user is new, create a default profile.
                // The companyId would ideally be set during a proper onboarding flow.
                await setDoc(userDocRef, {
                    uid: user.uid,
                    email: user.email,
                    name: user.displayName,
                    role: 'empleado', 
                    companyId: 1, // Defaulting to company 1 for new sign-ups
                });
            }
            // onAuthStateChanged in App.tsx will handle the rest.
        } catch (error) {
            console.error("Error during Google sign-in:", error);
            alert(`Error al iniciar sesión. Por favor, intente de nuevo.`);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <button
            onClick={handleGoogleSignIn}
            disabled={isLoading}
            className="w-full flex justify-center items-center py-3 px-4 border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-transform hover:scale-105 disabled:opacity-75 disabled:cursor-wait"
        >
            {isLoading ? <Spinner /> : <img className="w-5 h-5 mr-3" src="https://www.svgrepo.com/show/475656/google-color.svg" alt="Google logo" />}
            {isLoading ? 'Iniciando Sesión...' : 'Ingresar con Google'}
        </button>
    );
};

const EmailSignInForm = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSignIn = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');
        try {
            await signInWithEmailAndPassword(auth, email, password);
            // onAuthStateChanged in App.tsx will handle the rest.
        } catch (err: any) {
            console.error("Error signing in with email/password:", err);
            if (['auth/user-not-found', 'auth/wrong-password', 'auth/invalid-credential'].includes(err.code)) {
                setError('Correo electrónico o contraseña incorrectos.');
            } else {
                setError('Ocurrió un error al iniciar sesión.');
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <form onSubmit={handleSignIn} className="space-y-4">
            {error && <p className="text-red-500 text-sm text-center bg-red-100 p-2 rounded-md">{error}</p>}
            <div>
                <label htmlFor="email" className="sr-only">Email</label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="appearance-none rounded-md relative block w-full px-3 py-2 border border-slate-300 placeholder-slate-500 text-slate-900 focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                    placeholder="Correo electrónico"
                />
            </div>
            <div>
                <label htmlFor="password" className="sr-only">Password</label>
                <input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="appearance-none rounded-md relative block w-full px-3 py-2 border border-slate-300 placeholder-slate-500 text-slate-900 focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                    placeholder="Contraseña"
                />
            </div>
            <button
                type="submit"
                disabled={isLoading}
                className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-400 disabled:cursor-not-allowed"
            >
                {isLoading ? <Spinner /> : 'Ingresar'}
            </button>
        </form>
    );
};


const LoginPage: React.FC = () => {
  return (
    <div 
      className="min-h-screen bg-slate-200 bg-cover bg-center flex items-center justify-center p-4"
      style={{ backgroundImage: "url('https://images.unsplash.com/photo-1556761175-b413da4b2489?q=80&w=2070&auto=format&fit=crop')" }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/60 to-slate-900/70 backdrop-blur-sm"></div>
      
      <div className="relative z-10 container mx-auto flex flex-col lg:flex-row items-center justify-center">
        
        <div className="lg:w-1/2 text-center lg:text-left mb-10 lg:mb-0 lg:pr-20 flex flex-col items-center lg:items-start">
          <Logo className="h-32 w-32 mb-6" />
          <h1 className="text-6xl font-bold text-white mb-4" style={{textShadow: '2px 2px 8px rgba(0,0,0,0.6)'}}>Talento Sostenible</h1>
          <p className="mt-2 text-xl text-slate-200" style={{textShadow: '1px 1px 4px rgba(0,0,0,0.6)'}}>
            Impulsando el crecimiento de PYMES con soluciones a medida.
          </p>
        </div>

        <div className="lg:w-1/2 w-full max-w-md">
          <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-2xl p-8 border border-white/20">
            <h2 className="text-2xl font-bold text-center text-slate-800 mb-2">Bienvenido</h2>
            <p className="text-center text-slate-500 mb-6 text-sm">Inicie sesión para acceder a la plataforma.</p>
            <div className="space-y-4">
              <EmailSignInForm />
               <div className="relative my-4">
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="w-full border-t border-slate-300" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-slate-500">O continúa con</span>
                </div>
              </div>
              <GoogleSignInButton />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
